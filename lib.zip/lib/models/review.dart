class Review {
  final int id;
  final int userId;
  final int mediaItemId;
  final double rating;
  final String comment;

  Review(
      {required this.id,
      required this.userId,
      required this.mediaItemId,
      required this.rating,
      required this.comment});

  factory Review.fromJson(Map<String, dynamic> json) {
    return Review(
      id: json['id'],
      userId: json['user_id'],
      rating: (json['rating'] as num).toDouble(),
      comment: json['comment'],
      mediaItemId: json['mediaItemId'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'itemID': id,
      'userId': userId,
      'rating': rating,
      'comment': comment,
      'mediaItemId': mediaItemId,
    };
  }
}
