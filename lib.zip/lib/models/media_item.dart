class MediaItem {
  final int id;
  final String title;
  final String description;
  final String posterUrl;
  final double rating;
  final DateTime? releaseDate;
  final List<String> genre;
  final int? numberOfEpisodes; // Null for movies
  final int? numberOfSeasons; // Null for movies

  MediaItem(
      {required this.id,
      required this.title,
      required this.description,
      required this.posterUrl,
      required this.rating,
      required this.releaseDate,
      required this.genre,
      this.numberOfEpisodes,
      this.numberOfSeasons});
  factory MediaItem.fromJson(Map<String, dynamic> json) {
    DateTime? parseDate(String? date) {
      if (date == null || date.isEmpty) return null;
      try {
        return DateTime.parse(date);
      } catch (_) {
        // If the date format is invalid, return null
        return null;
      }
    }

    return MediaItem(
      id: json['id'] as int? ?? 0,
      title: json['title'] as String? ?? 'Unknown',
      description: json['overview'] as String? ?? 'No description available.',
      posterUrl: json['poster_path'] != null
          ? 'https://image.tmdb.org/t/p/w500${json['poster_path']}'
          : 'https://via.placeholder.com/500x750?text=No+Image', // Placeholder image URL
      releaseDate: parseDate(json['release_date'] as String?),
      rating: (json['vote_average'] as num?)?.toDouble() ?? 0.0,
      genre: (json['genre'] as List)
          .map((g) => g['name'] as String)
          .toList(), // Initialize in constructor
    );
  }
}
