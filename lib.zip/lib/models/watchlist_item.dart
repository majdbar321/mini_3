class WatchlistItem {
  final int mediaItemId;
  final bool watched;

  WatchlistItem({required this.mediaItemId, required this.watched});
}
