import 'package:flutter/material.dart';
import '../models/media_item.dart';
import 'rating_bar.dart'; // Custom widget for displaying ratings

class MediaItemCard extends StatelessWidget {
  final MediaItem mediaItem;

  MediaItemCard({required this.mediaItem});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5,
      margin: EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Poster Image
          Image.network(
            mediaItem.posterUrl,
            fit: BoxFit.cover,
            height: 200,
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Title
                Text(
                  mediaItem.title,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  overflow: TextOverflow.ellipsis,
                ),
                SizedBox(height: 5),
                // Rating Bar
                RatingBar(rating: mediaItem.rating),
                SizedBox(height: 5),
                // Additional Details (Year, Genre)
                Text(
                  '${mediaItem.releaseDate} • ${mediaItem.genre.join(', ')}',
                  style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                ),
                SizedBox(height: 5),
                // Summary
                Text(
                  mediaItem.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
