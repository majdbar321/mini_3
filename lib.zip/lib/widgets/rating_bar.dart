import 'package:flutter/material.dart';

class RatingBar extends StatelessWidget {
  final double rating;
  final bool isReadOnly;
  final ValueChanged<double>? onRatingChanged;

  RatingBar(
      {required this.rating, this.isReadOnly = true, this.onRatingChanged});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (index) {
        return GestureDetector(
          onTap: isReadOnly ? null : () => onRatingChanged?.call(index + 1.0),
          child: Icon(
            index < rating ? Icons.star : Icons.star_border,
            color: Colors.amber,
            size: 24,
          ),
        );
      }),
    );
  }
}
