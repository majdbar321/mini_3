import 'package:flutter/material.dart';
import '/models/review.dart';

class ReviewScreen extends StatelessWidget {
  final int mediaItemId;

  ReviewScreen({required this.mediaItemId});

  @override
  Widget build(BuildContext context) {
    // Placeholder data - replace with actual data fetching logic
    final List<Review> reviews = []; // List of reviews for the media item

    return Scaffold(
      appBar: AppBar(
        title: Text('Reviews'),
      ),
      body: ListView.builder(
        itemCount: reviews.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text('User: ${reviews[index].userId}'),
            subtitle: Text(reviews[index].comment),
            trailing: Text('Rating: ${reviews[index].rating}'),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          // Logic to add a new review
        },
      ),
    );
  }
}
