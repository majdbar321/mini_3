import 'package:flutter/material.dart';
import '/models/media_item.dart';

class MediaDetailScreen extends StatelessWidget {
  final MediaItem mediaItem;

  MediaDetailScreen({required this.mediaItem});

  @override
  Widget build(BuildContext context) {
    // Placeholder data - replace with actual data fetching logic
    final List<String> castMembers = [
      'Actor 1',
      'Actor 2',
      'Actor 3'
    ]; // Example cast members
    final String director = 'Director Name'; // Example director
    final String pegiInfo = 'PG-13'; // Example PEGI info
    final String genre = 'Action, Drama'; // Example genre
    // Example icons for user selected services (e.g., Netflix, Hulu)
    final List<Icon> serviceIcons = [Icon(Icons.movie), Icon(Icons.tv)];

    return Scaffold(
      appBar: AppBar(
        title: Text(mediaItem.title),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(
              mediaItem.posterUrl,
              fit: BoxFit.cover,
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    mediaItem.title,
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Rating: ${mediaItem.rating.toString()} / 10',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Release Date: ${mediaItem.releaseDate}',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Director: $director',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Genre: $genre',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'PEGI Rating: $pegiInfo',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Cast Members:',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                  ),
                  ...castMembers.map((actor) => ListTile(title: Text(actor))),
                  SizedBox(height: 8),
                  Text(
                    'Summary:',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                  ),
                  Text(mediaItem.description),
                  if (mediaItem.numberOfSeasons != null) ...[
                    SizedBox(height: 8),
                    Text(
                      'Seasons: ${mediaItem.numberOfSeasons}',
                      style: TextStyle(fontSize: 16),
                    ),
                    // Optional: Navigation across seasons
                  ],
                  if (mediaItem.numberOfEpisodes != null) ...[
                    SizedBox(height: 8),
                    Text(
                      'Episodes: ${mediaItem.numberOfEpisodes}',
                      style: TextStyle(fontSize: 16),
                    ),
                    // Optional: Navigation across episodes
                  ],
                  SizedBox(height: 8),
                  Row(
                    children: serviceIcons,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
